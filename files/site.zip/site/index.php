<?php
echo "<h1>Hello from Abdul!</h1>";
phpinfo();
?>
